import { defineMcpClientConnection } from "eve/connections";
import { always } from "eve/tools/approval";

// Composio Connect: one MCP server fronting 1000+ apps (Gmail, Google
// Calendar, Notion, Slack, GitHub, Linear, ...). It exposes meta-tools to
// discover app tools, authorize apps, and execute actions. When an app is
// not connected yet, its manage-connections tool returns an OAuth link the
// user opens in a browser; the resulting connection persists across sessions.
//
// `approval: always()` is deliberate and not the framework default (an
// omitted `approval` here would mean every action - across every connected
// app - runs with zero human check, per eve's own docs). This connection is
// a single point of leverage over arbitrary external systems: sending mail,
// deleting calendar events, pushing to a repo. There is no reliable way to
// tell a safe read from a consequential write from the tool schema alone
// (Composio's action set is discovered at runtime, not declared here), so
// the gate is blanket rather than tiered until real usage shows which
// specific actions are safe to exempt with a narrower Approval function.
export default defineMcpClientConnection({
  url: "https://connect.composio.dev/mcp",
  description:
    "Composio: gateway to the user's connected apps (Gmail, Google Calendar, Notion, Slack, GitHub, Linear, and 1000+ more). Search for app tools, connect or authorize apps (returns an OAuth link to show the user), check connection status, and execute app actions like reading email, creating calendar events, or updating Notion pages.",
  headers: {
    "x-consumer-api-key": () => process.env.COMPOSIO_API_KEY!,
  },
  approval: always(),
});
