import { randomBytes } from "node:crypto";

import { db } from "./receipts-db";

// Agent-managed webhooks (event triggers): each row is an inbound HTTP
// endpoint with a stored instruction. The hooks channel
// (agent/channels/hooks.ts) receives POSTs at /eve/v1/hooks/:id/:secret,
// verifies the secret, and wakes the agent with the stored prompt plus the
// event payload. Delivery follows origin like reminders: Telegram-created
// hooks report into that DM, web-created ones land as web chat threads.
//
// Two protections live here rather than at the framework level, since a
// bare authenticated HTTP endpoint with no rate limit or expiry is real
// exposure once its secret leaks or a sender misbehaves: a minimum
// interval between agent-wakes (recordWebhookThrottled / isThrottled),
// and optional expiry (isExpired) so a webhook created for one occasion
// doesn't sit live indefinitely waiting for someone to remember to call
// delete_webhook.

export interface WebhookRow {
  id: string;
  secret: string;
  name: string;
  prompt: string;
  chat_id: string | null;
  created_at: string;
  last_fired_at: string | null;
  fire_count: number;
  throttled_count: number;
  expires_at: string | null;
}

const PROJECTION = `
  id,
  secret,
  name,
  prompt,
  chat_id,
  created_at::text AS created_at,
  last_fired_at::text AS last_fired_at,
  fire_count,
  throttled_count,
  expires_at::text AS expires_at
`;

let ensured = false;

async function ensureTable(): Promise<void> {
  if (ensured) return;
  await db().query(`
    CREATE TABLE IF NOT EXISTS webhooks (
      id text PRIMARY KEY,
      secret text NOT NULL,
      name text NOT NULL,
      prompt text NOT NULL,
      chat_id text,
      created_at timestamptz NOT NULL DEFAULT now(),
      last_fired_at timestamptz,
      fire_count integer NOT NULL DEFAULT 0,
      throttled_count integer NOT NULL DEFAULT 0,
      expires_at timestamptz
    )
  `);
  // ALTER-if-missing rather than a migration file, matching how this
  // single-table store already handles its own schema: the CREATE above
  // only helps a fresh database, and this app has no migration runner.
  await db().query(`ALTER TABLE webhooks ADD COLUMN IF NOT EXISTS throttled_count integer NOT NULL DEFAULT 0`);
  await db().query(`ALTER TABLE webhooks ADD COLUMN IF NOT EXISTS expires_at timestamptz`);
  ensured = true;
}

export async function createWebhook(input: {
  name: string;
  prompt: string;
  chatId: string | null;
  expiresAt: Date | null;
}): Promise<WebhookRow> {
  await ensureTable();
  const id = `whk_${randomBytes(6).toString("hex")}`;
  const secret = randomBytes(24).toString("hex");
  const rows = await db().query(
    `INSERT INTO webhooks (id, secret, name, prompt, chat_id, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING ${PROJECTION}`,
    [id, secret, input.name, input.prompt, input.chatId, input.expiresAt],
  );
  return rows[0] as WebhookRow;
}

export async function listWebhooks(): Promise<WebhookRow[]> {
  await ensureTable();
  const rows = await db().query(`SELECT ${PROJECTION} FROM webhooks ORDER BY created_at ASC`);
  return rows as WebhookRow[];
}

export async function getWebhook(id: string): Promise<WebhookRow | null> {
  await ensureTable();
  const rows = await db().query(`SELECT ${PROJECTION} FROM webhooks WHERE id = $1`, [id]);
  return (rows[0] as WebhookRow | undefined) ?? null;
}

export async function deleteWebhook(id: string): Promise<WebhookRow | null> {
  await ensureTable();
  const rows = await db().query(
    `DELETE FROM webhooks WHERE id = $1 RETURNING ${PROJECTION}`,
    [id],
  );
  return (rows[0] as WebhookRow | undefined) ?? null;
}

export async function recordWebhookFire(id: string): Promise<void> {
  await db().query(
    `UPDATE webhooks SET last_fired_at = now(), fire_count = fire_count + 1 WHERE id = $1`,
    [id],
  );
}

export async function recordWebhookThrottled(id: string): Promise<void> {
  await db().query(`UPDATE webhooks SET throttled_count = throttled_count + 1 WHERE id = $1`, [id]);
}

// Minimum time between agent-wakes per webhook. A leaked secret or a
// misconfigured sender's retry storm otherwise wakes the agent - a real
// model call, not a free operation - on every single request, unbounded.
// This is a floor on cost and noise, not a claim that every event within
// the window is unimportant: an event that arrives while throttled is
// dropped, not queued, so a webhook feeding truly rapid-fire events one at
// a time is the wrong fit for this mechanism, not just under-tuned.
export const MIN_SECONDS_BETWEEN_FIRES = 10;

export function isThrottled(hook: Pick<WebhookRow, "last_fired_at">): boolean {
  if (hook.last_fired_at === null) return false;
  const elapsedMs = Date.now() - new Date(hook.last_fired_at).getTime();
  return elapsedMs < MIN_SECONDS_BETWEEN_FIRES * 1000;
}

export function isExpired(hook: Pick<WebhookRow, "expires_at">): boolean {
  if (hook.expires_at === null) return false;
  return Date.now() >= new Date(hook.expires_at).getTime();
}

/** Public URL for a webhook. Prefers the stable production domain. */
export function webhookUrl(hook: Pick<WebhookRow, "id" | "secret">): string {
  const host =
    process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL ?? null;
  const base = host !== null ? `https://${host}` : `http://localhost:${process.env.PORT ?? "3000"}`;
  return `${base}/eve/v1/hooks/${hook.id}/${hook.secret}`;
}
