import { defineRemoteAgent } from "eve";
import { bearer } from "eve/agents/auth";

// Eve's native equivalent of firstmate's local-first-mate -> Mac-Mini-
// secondmate dispatch: a separately deployed Atlas (or any eve deployment)
// running elsewhere, called the same way as a local subagent - same
// `task` tool shape, same subagent.called/completed stream events. Unlike
// firstmate's SSH+tmux+treehouse mechanism (built for spawning independent
// CLI-harness processes on a remote host), this is durable and
// callback-based at the framework level: the parent turn parks without
// holding compute while the remote works, and resumes when the remote
// posts back - so a parent restart or redeploy mid-dispatch does not lose
// the in-flight call the way killing an SSH session would.
//
// url is a function, not a string, because the target - wherever "mini"
// actually is - is only known once you've deployed something there and
// set MINI_AGENT_URL; a bare string would freeze a URL that doesn't exist
// yet into the compiled build.
//
// auth uses a static bearer token, not vercelOidc(), because a Mac Mini
// running self-hosted is not a Vercel deployment - OIDC deployment-to-
// deployment trust has nothing to attest here. Set MINI_AGENT_TOKEN to a
// long random secret on both sides; whatever runs on the Mini must check
// it on the receiving end (see docs/guides/auth-and-route-protection.md
// in the eve package for the receiving-side setup).
export default defineRemoteAgent({
  url: () => {
    const url = process.env.MINI_AGENT_URL;
    if (url === undefined || url.trim().length === 0) {
      throw new Error(
        "MINI_AGENT_URL is not set - point it at the eve deployment running on the remote machine before calling this subagent.",
      );
    }
    return url;
  },
  description:
    "Delegate to the agent instance running on the other machine (the Mini). Use for work that specifically needs to run there - access to files, tools, or state that only exist on that machine - not as a generic way to parallelize work you could do locally.",
  auth: bearer(() => {
    const token = process.env.MINI_AGENT_TOKEN;
    if (token === undefined || token.trim().length === 0) {
      throw new Error("MINI_AGENT_TOKEN is not set.");
    }
    return token;
  }),
});
