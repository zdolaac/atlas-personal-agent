import { defineTool } from "eve/tools";
import { z } from "zod";
import { memoryStore } from "../../../lib/memory-store";

// Same unvalidated threshold as the parent's search_memory tool (see that
// file's comment) - kept in sync manually since this subagent has its own
// copy by design, not a shared import.
const MIN_SIMILARITY = 0.15;

// Reuses the parent's memory store directly rather than duplicating its
// logic - this subagent is scoped down by which tools exist in this folder,
// not by a separate implementation of the same one.
export default defineTool({
  description: "Search long-term memory for saved facts relevant to a query.",
  inputSchema: z.object({
    query: z.string().min(1).max(500).describe("What to look for, phrased as a plain question or topic"),
  }),
  async execute({ query }) {
    const results = await memoryStore.search(query, { minSimilarity: MIN_SIMILARITY });
    return { results };
  },
});
