import { defineAgent } from "eve";

// The first real subagent node: proof that Atlas can stamp out a distinct,
// independently-scoped agent instance rather than just new skills for
// itself. Compiled by eve into its own graph node with its own model call,
// its own tools/ folder (no inheritance from agent/tools/ - the parent's
// forget, create_webhook, share_file, and Composio access simply do not
// exist here, the same structural guarantee neural-code's subagent.py
// relies on: absence, not a prompt asking nicely), and its own
// instructions.md. Invoked by the parent via the task tool, using the
// description below as the tool's description.
export default defineAgent({
  description:
    "Read-only research: answers a self-contained question using long-term memory search. Cannot write, delete, message anyone, or take any external action. Give it a question with no assumed context - it cannot see the parent conversation.",
  model: "anthropic/claude-haiku-4-5",
});
