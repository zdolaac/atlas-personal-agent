import { defineTool } from "eve/tools";
import { always } from "eve/tools/approval";
import { z } from "zod";
import { db } from "../lib/receipts-db";

export default defineTool({
  description:
    "Delete one logged receipt by its id. Use to correct a mistaken or duplicate entry; find the id with query_receipts first.",
  inputSchema: z.object({
    id: z.number().int().positive().describe("Receipt id from query_receipts"),
  }),
  // A financial record, deleted. If spending_summary is ever load-bearing
  // for anything (budgeting, taxes, a dispute), a silently-deleted row is
  // the wrong kind of thing to lose to an agent's own initiative.
  approval: always(),
  async execute({ id }) {
    const rows = await db().query("DELETE FROM receipts WHERE id = $1 RETURNING id", [id]);
    return { deleted: rows.length > 0 };
  },
});
