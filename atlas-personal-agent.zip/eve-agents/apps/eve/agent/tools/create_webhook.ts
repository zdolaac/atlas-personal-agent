import { defineTool } from "eve/tools";
import { always } from "eve/tools/approval";
import { z } from "zod";

import { createWebhook, webhookUrl } from "../lib/webhooks-db";

function telegramChatId(attributes: Record<string, unknown>): string | null {
  const chatId = attributes.chat_id;
  return chatId === undefined || chatId === null ? null : String(chatId);
}

export default defineTool({
  description:
    "Create an event trigger: a webhook URL that wakes you when an external service POSTs to it (deploy failed, form submitted, payment received, email rule matched). You receive the payload, follow the stored instruction, and message Micky. Give him the returned URL to paste into the service. Fires are rate-limited (one wake per hook per 10s; faster events are acked but not delivered) and, if expiresInHours is set, the hook deletes itself after that window rather than living indefinitely.",
  inputSchema: z.object({
    name: z
      .string()
      .min(1)
      .max(120)
      .describe('Short human label for what sends to this hook, e.g. "Vercel deploy alerts".'),
    prompt: z
      .string()
      .min(1)
      .max(4000)
      .describe(
        "Instruction to your future self when an event arrives: how to interpret the payload, what to check or do, and what to tell Micky. The fired session has no chat history, so include all context.",
      ),
    expiresInHours: z
      .number()
      .positive()
      .max(24 * 365)
      .optional()
      .describe(
        "Optional: auto-delete this hook this many hours from now. Use for one-off or time-bounded events " +
          "(a specific deploy window, a temporary integration test) rather than leaving a standing endpoint " +
          "for something that only ever needed to fire once. Omit for hooks meant to live indefinitely.",
      ),
  }),
  // A live webhook is a standing, unauthenticated entry point into the
  // agent - "treat it like a password" below is advice to the user, not
  // enforcement. Requiring approval on the call that mints it is the
  // enforcement: creation is the one moment a human can still say no.
  approval: always(),
  async execute({ name, prompt, expiresInHours }, ctx) {
    // Delivery follows origin: a hook created from Telegram reports into that
    // DM; one created from web chat lands as a new web chat thread.
    const attributes = ctx.session.auth.current?.attributes ?? {};
    const hook = await createWebhook({
      name,
      prompt,
      chatId: telegramChatId(attributes),
      expiresAt: expiresInHours !== undefined ? new Date(Date.now() + expiresInHours * 3600_000) : null,
    });

    return {
      id: hook.id,
      name: hook.name,
      url: webhookUrl(hook),
      expiresAt: hook.expires_at,
      note: "Anyone with this URL can trigger the hook; treat it like a password.",
    };
  },
});
