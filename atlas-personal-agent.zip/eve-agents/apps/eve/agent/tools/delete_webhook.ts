import { defineTool } from "eve/tools";
import { once } from "eve/tools/approval";
import { z } from "zod";

import { deleteWebhook } from "../lib/webhooks-db";

export default defineTool({
  description:
    "Delete an event-trigger webhook by id (find it with list_webhooks). The URL stops working immediately; remind Micky to remove it from the sending service too.",
  inputSchema: z.object({
    id: z.string().min(1),
  }),
  // Removing a hook shrinks the attack surface rather than growing it, so
  // this is lower-stakes than create_webhook - but it can also silently
  // break an automation Micky is relying on. `once()` per session is enough
  // friction to catch that without asking on every single deletion.
  approval: once(),
  async execute({ id }) {
    const deleted = await deleteWebhook(id);
    if (deleted === null) {
      throw new Error(`No webhook with id ${id}. Use list_webhooks to see current ids.`);
    }
    return { id: deleted.id, name: deleted.name, deleted: true };
  },
});
