import { defineTool } from "eve/tools";
import { z } from "zod";
import { memoryStore } from "../lib/memory-store";

// Hands-On Large Language Models (Alammar & Grootendorst), ch. 8: "should
// [a weak match] even be returned as a result? ... it's sometimes
// desirable to have a max threshold of similarity score to filter out
// irrelevant results." Applied here - but the actual number is an
// unvalidated guess, not a tuned value: Supermemory's hybrid-search score
// scale and distribution were never measured against real query/result
// pairs from this deployment. If memory search starts feeling like it
// misses things that should have matched, raise suspicion on this
// constant first, not on the underlying search.
const MIN_SIMILARITY = 0.15;

export default defineTool({
  description:
    "Search long-term memory for saved facts and past context relevant to a query. Use when the user references something not covered by the memory profile injected into this turn.",
  inputSchema: z.object({
    query: z.string().min(1).max(500).describe("What to look for, phrased as a plain question or topic"),
  }),
  async execute({ query }) {
    const results = await memoryStore.search(query, { minSimilarity: MIN_SIMILARITY });
    return { results };
  },
});
