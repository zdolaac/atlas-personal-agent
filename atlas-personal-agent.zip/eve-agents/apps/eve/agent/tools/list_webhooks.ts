import { defineTool } from "eve/tools";
import { z } from "zod";

import { listWebhooks, webhookUrl } from "../lib/webhooks-db";

export default defineTool({
  description:
    "List event-trigger webhooks: id, name, stored instruction, URL, fire/throttle stats, and expiry. Use when Micky asks what triggers exist, needs a hook's URL again, wants an id to delete, or you're checking whether one is being hit too often.",
  inputSchema: z.object({}),
  async execute() {
    const hooks = await listWebhooks();
    return {
      webhooks: hooks.map((hook) => ({
        id: hook.id,
        name: hook.name,
        prompt: hook.prompt,
        url: webhookUrl(hook),
        createdAt: hook.created_at,
        lastFiredAt: hook.last_fired_at,
        fireCount: hook.fire_count,
        throttledCount: hook.throttled_count,
        expiresAt: hook.expires_at,
      })),
    };
  },
});
