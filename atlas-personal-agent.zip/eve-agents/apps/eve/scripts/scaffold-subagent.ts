// The foundation machine: turns a short charter into a new subagent
// scaffold under agent/subagents/<id>/ - a distinct, restricted product-
// machine node, not just new tooling for the existing one. Pass
// --remote-url to scaffold a remote-agent file instead (a single
// agent/subagents/<id>.ts calling a separately deployed eve instance,
// e.g. one running on another machine) rather than a local folder.
//
// This writes files to your own checkout; it is a developer-run script,
// not an Atlas tool. Atlas has no filesystem-write access to its own
// deployed source and shouldn't be given one just to make this dynamic -
// a new subagent changes what the whole system can do, and that belongs
// behind a human running a command and reviewing a diff before deploy,
// the same way a real mother machine's output gets bolted into the press
// by a person, not by the press itself.
//
// Usage (from apps/eve/), local subagent:
//   npx tsx scripts/scaffold-subagent.ts <id> \
//     --description "One line: what this subagent does and when the parent should call it" \
//     --model "anthropic/claude-haiku-4-5"
//
// Usage, remote subagent (another machine/deployment):
//   npx tsx scripts/scaffold-subagent.ts <id> \
//     --description "..." \
//     --remote-url "MINI_AGENT_URL"   # name of the env var holding the URL, not the URL itself
//
// After a local scaffold: open agent/subagents/<id>/tools/ and add exactly
// the tools this subagent needs. The empty folder is deliberate - an empty
// toolset is the safe default, not an oversight to fill in later.
// After a remote scaffold: set the named env var (and its matching
// *_TOKEN, if you keep the bearer-auth pattern) before it can be called.

import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

interface Charter {
  readonly id: string;
  readonly description: string;
  readonly model: string;
  readonly remoteUrlEnvVar: string | null;
}

function parseArgs(argv: readonly string[]): Charter {
  const [id, ...rest] = argv;
  if (id === undefined || !/^[a-z][a-z0-9-]*$/.test(id)) {
    throw new Error(
      'First argument must be a lowercase-hyphenated id, e.g. "researcher" or "pr-reviewer".',
    );
  }

  let description: string | null = null;
  let model = "anthropic/claude-haiku-4-5";
  let remoteUrlEnvVar: string | null = null;
  for (let i = 0; i < rest.length; i += 1) {
    if (rest[i] === "--description") description = rest[++i] ?? null;
    else if (rest[i] === "--model") model = rest[++i] ?? model;
    else if (rest[i] === "--remote-url") remoteUrlEnvVar = rest[++i] ?? null;
  }

  if (description === null || description.trim().length === 0) {
    throw new Error(
      "--description is required: what this subagent does and when the parent should call it. " +
        "This becomes the tool description the parent model sees, so it has to be a real judgment call, not a placeholder.",
    );
  }
  if (remoteUrlEnvVar !== null && !/^[A-Z][A-Z0-9_]*$/.test(remoteUrlEnvVar)) {
    throw new Error(
      "--remote-url takes the NAME of an env var (e.g. MINI_AGENT_URL), not a literal URL - " +
        "the URL is only known once you've deployed something there.",
    );
  }

  return { id, description, model, remoteUrlEnvVar };
}

function agentTs(charter: Charter): string {
  return `import { defineAgent } from "eve";

// Scaffolded by scripts/scaffold-subagent.ts. Review this file, then add
// the tools this subagent actually needs under ./tools/ - it starts with
// none, deliberately: an empty toolset is the safe default.
export default defineAgent({
  description:
    ${JSON.stringify(charter.description)},
  model: ${JSON.stringify(charter.model)},
});
`;
}

function remoteAgentTs(charter: Charter, envVar: string): string {
  const tokenEnvVar = `${envVar.replace(/_URL$/, "")}_TOKEN`;
  return `import { defineRemoteAgent } from "eve";
import { bearer } from "eve/agents/auth";

// Scaffolded by scripts/scaffold-subagent.ts --remote-url. Calls a
// separately deployed eve instance rather than running in this process.
// Set ${envVar} (and ${tokenEnvVar}, if that deployment checks it) before
// this subagent is callable - until then, calling it throws immediately
// rather than silently failing.
export default defineRemoteAgent({
  url: () => {
    const url = process.env.${envVar};
    if (url === undefined || url.trim().length === 0) {
      throw new Error("${envVar} is not set.");
    }
    return url;
  },
  description:
    ${JSON.stringify(charter.description)},
  auth: bearer(() => {
    const token = process.env.${tokenEnvVar};
    if (token === undefined || token.trim().length === 0) {
      throw new Error("${tokenEnvVar} is not set.");
    }
    return token;
  }),
});
`;
}

function instructionsMd(charter: Charter): string {
  return `# Identity

You are the "${charter.id}" subagent, spawned for one self-contained task.
You have no access to the conversation that spawned you and no memory of
any other run - each invocation starts cold. State every fact the task
needs; nothing is implied.

# What you can do

Whatever tools exist in this subagent's tools/ folder - nothing else. If a
task needs a capability you don't have, say so in your final message rather
than attempting a workaround through the tools you do have.

# How to answer

The parent agent sees only your final message, never your intermediate
tool calls - make it stand on its own: what you did, what you found or
produced, and anything the parent needs to know to act on it.

<!-- Fill in task-specific guidance below. -->
`;
}

async function main(): Promise<void> {
  const charter = parseArgs(process.argv.slice(2));

  if (charter.remoteUrlEnvVar !== null) {
    const filePath = path.join(process.cwd(), "agent", "subagents", `${charter.id}.ts`);
    await writeFile(filePath, remoteAgentTs(charter, charter.remoteUrlEnvVar));
    console.log(`Scaffolded agent/subagents/${charter.id}.ts (remote agent)`);
    console.log(`Next: set ${charter.remoteUrlEnvVar}, deploy the remote side, then npm run build.`);
    return;
  }

  const root = path.join(process.cwd(), "agent", "subagents", charter.id);
  await mkdir(path.join(root, "tools"), { recursive: true });
  await writeFile(path.join(root, "agent.ts"), agentTs(charter));
  await writeFile(path.join(root, "instructions.md"), instructionsMd(charter));
  await writeFile(
    path.join(root, "tools", ".gitkeep"),
    "# Add this subagent's tools here. An empty folder means it can only think, not act.\n",
  );

  console.log(`Scaffolded agent/subagents/${charter.id}/`);
  console.log("Next: add its tools, review instructions.md, then npm run build to compile it in.");
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
