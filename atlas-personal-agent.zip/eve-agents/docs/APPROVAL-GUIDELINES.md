# Approval-tier guideline for Atlas tools

Written separately from the tools it governs, on purpose. Each existing
`approval:` call was justified in a comment at the moment it was written -
which means the next tool added has nothing to check itself against except
"what did the last one do." This document is that standard, made explicit,
so a reviewer (human or a future Claude session) can evaluate a new tool's
approval tier *before* looking at what tier was actually chosen, the same
separation AI Engineering (Huyen, ch. 4) argues for between defining
criteria and applying them.

## The rubric

Ask these in order. The first one that applies decides the tier; later
questions only matter if earlier ones don't settle it.

1. **Is the action irreversible, with harm that's silent until it's
   needed?** (deleting data, deleting a memory, deleting a financial
   record) → `always()`. The distinguishing feature isn't severity alone -
   it's that the person affected won't notice the loss at the moment it
   happens, only later, when whatever was deleted turns out to have
   mattered.
2. **Does the action create a new, standing point of external exposure?**
   (a public URL, a webhook endpoint, anything reachable by something
   other than this conversation) → `always()`. Every call that mints one
   is a separate decision, not a one-time setup step - a tool that's
   cheap to call is exactly the kind that gets called more than once.
3. **Does the action reduce exposure or attack surface rather than
   create it?** (deleting a webhook, revoking access) → `once()` per
   session is enough. Lower stakes than #2 in the same tool family, but
   still worth one confirmation, since it can silently break an
   automation the user was relying on.
4. **Is the action a gateway to arbitrary external systems whose specific
   operations aren't enumerable from here?** (Composio, or any other
   MCP connection fronting many apps) → `always()`, blanket, regardless
   of whether any individual call underneath it would otherwise qualify
   for a lighter tier. The reason is structural, not a judgment about
   Composio specifically: this codebase cannot see, at review time, the
   full set of actions such a connection might expose, so it cannot
   assign per-action tiers with real confidence. Reassess only if the
   connection type starts exposing a declared, closed set of operations
   this repo can enumerate.
5. **Otherwise** (reads, reversible local writes with no external
   reach) → no `approval` field. Eve's own default (`never()`) applies.
   Gating everything regardless of risk teaches the user to click through
   approvals without reading them, which is worse than gating nothing.

## Applied to every tool that currently has a tier

| Tool | Tier | Rubric question it satisfies |
|---|---|---|
| `connections/composio.ts` | `always()` | #4 - ungoverned gateway to arbitrary apps |
| `tools/create_webhook.ts` | `always()` | #2 - mints a new externally-reachable URL |
| `tools/share_file.ts` | `always()` | #2 - mints a new public URL |
| `tools/forget.ts` | `always()` | #1 - irreversible, silent-until-needed loss |
| `tools/delete_receipt.ts` | `always()` | #1 - irreversible financial-record loss |
| `tools/delete_webhook.ts` | `once()` | #3 - reduces exposure, but can break a relied-on automation |

No tool currently resolves at question #5 with an explicit `never()` - the
untiered tools (`remember`, `search_memory`, `list_memories`,
`create_reminder`, `list_reminders`, `cancel_reminder`, `list_webhooks`,
`log_receipt`, `query_receipts`, `spending_summary`, `roll_dice`,
`get_weather`, `workflow`) simply have no `approval` field, which is the
correct way to land there - Eve's own default, not an override.

## What this guideline does not cover

- **Subagent tool grants** (what's *in* `agent/subagents/<id>/tools/`) are
  a different question from approval tiers - an empty tools folder is a
  stronger guarantee than any approval setting, since there's nothing to
  approve or deny. See the reasoning in `scripts/scaffold-subagent.ts`.
- **Remote agents** (`defineRemoteAgent`) have no approval field of their
  own in Eve's API - whatever tier applies is whatever the *remote*
  deployment sets on its own tools. `agent/subagents/mini.ts` inherits
  nothing from this document; if a second eve deployment is ever stood up
  to receive its calls, that deployment's own tools need their own pass
  through this same rubric.
- **This rubric is not self-verifying.** There is no test that confirms
  "every tool matching rubric criterion N has tier N" - that would require
  parsing every tool file's actual risk profile programmatically, which
  this repo doesn't attempt. This table is a manually-maintained cross-
  check, current as of the tools listed above; a new tool that skips this
  document entirely would not be caught by anything automated.
