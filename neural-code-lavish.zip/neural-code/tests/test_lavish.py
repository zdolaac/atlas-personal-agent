"""Tests for neuralcode.lavish - the local review server.

These start a real ThreadingHTTPServer on an ephemeral loopback port and
drive it with real HTTP requests (urllib), the same way an actual browser
would - not mocks of the server internals. What they cannot do is drive an
actual browser: the client-side click-to-annotate JS, the live Mermaid
render, and the floating editor's positioning are exercised here only as
static content checks (the served page contains the right script/markup)
plus direct POSTs simulating what that JS would send. Click through it in
a real browser at least once before trusting the UX, not just this suite.
"""

import contextlib
import html
import io
import json
import re
import threading
import time
import urllib.error
import urllib.request

import pytest

from neuralcode import lavish
from neuralcode.lavish import open_diagram_review, open_review

TEST_TIMEOUT = 5  # seconds - short, so a broken wait-loop fails fast instead of hanging CI


def _run_and_capture_url(fn, *args, **kwargs):
    """Run fn (open_review or open_diagram_review) in a background thread,
    wait for it to print its URL, and return (url, thread, result_holder).

    fn's own stdout is captured into a buffer for the duration of the
    call - contextlib.redirect_stdout is process-global, not per-thread, so
    anything the *test* prints while this thread is still running would
    also be swallowed. Don't print from the test body between calling this
    and joining the returned thread; assert instead.
    """
    buf = io.StringIO()
    holder: dict = {}

    def run():
        with contextlib.redirect_stdout(buf):
            holder["value"] = fn(*args, **kwargs)

    thread = threading.Thread(target=run)
    thread.start()

    url = None
    for _ in range(50):
        time.sleep(0.1)
        match = re.search(r"http://127\.0\.0\.1:\d+/", buf.getvalue())
        if match:
            url = match.group(0)
            break

    if url is None:
        thread.join(timeout=1)
        raise AssertionError(f"server never printed a URL; captured output: {buf.getvalue()!r}")

    return url, thread, holder


def _post_feedback(url: str, payload: dict) -> None:
    request = urllib.request.Request(
        url.rstrip("/") + "/feedback",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    urllib.request.urlopen(request, timeout=TEST_TIMEOUT)


def _extract_token(page: str) -> str:
    match = re.search(r'const TOKEN = ("[^"]+");', page)
    assert match, "TOKEN not found in served page"
    return json.loads(match.group(1))


# --- open_review (free-text HTML artifact review) ---------------------------


def test_open_review_serves_injected_panel():
    url, thread, holder = _run_and_capture_url(
        open_review, "<html><body><h1>Plan</h1></body></html>", title="t", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    assert "neuralcode-review-panel" in page
    assert "Plan" in page
    _post_feedback(url, {"token": _extract_token(page), "feedback": "looks good"})
    thread.join(timeout=TEST_TIMEOUT)
    assert not thread.is_alive()
    assert holder["value"] == "looks good"


def test_open_review_rejects_wrong_token():
    url, thread, holder = _run_and_capture_url(
        open_review, "<html><body>x</body></html>", title="t", timeout_seconds=TEST_TIMEOUT
    )
    request = urllib.request.Request(
        url.rstrip("/") + "/feedback",
        data=json.dumps({"token": "not-the-real-token", "feedback": "nope"}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with pytest.raises(urllib.error.HTTPError) as excinfo:
        urllib.request.urlopen(request, timeout=TEST_TIMEOUT)
    assert excinfo.value.code == 403

    # The server is still waiting - a real token still completes the call,
    # proving the rejection didn't tear anything down.
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(url, {"token": _extract_token(page), "feedback": "real one"})
    thread.join(timeout=TEST_TIMEOUT)
    assert holder["value"] == "real one"


def test_open_review_dismiss_without_feedback():
    url, thread, holder = _run_and_capture_url(
        open_review, "<html><body>x</body></html>", title="t", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(url, {"token": _extract_token(page), "feedback": None})
    thread.join(timeout=TEST_TIMEOUT)
    assert holder["value"] == "The user closed the review without leaving feedback."


def test_open_review_times_out_when_nothing_arrives():
    _url, thread, holder = _run_and_capture_url(
        open_review, "<html><body>x</body></html>", title="t", timeout_seconds=1
    )
    thread.join(timeout=TEST_TIMEOUT)
    assert not thread.is_alive()
    assert "No feedback received within 1s" in holder["value"]


# --- open_diagram_review (Mermaid source + node-level review) ---------------

FLOWCHART = "flowchart TD\n  A[Start] --> B[Process] --> C[End]"


def test_diagram_page_has_click_to_annotate_machinery():
    url, thread, holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    for needle in (
        "attachNodeHandlers",
        "openNodeEditor",
        "node_annotations",
        "data-neuralcode-annotated",
        "sourceNodeId",
        "mermaid.esm.min.mjs",
        "stroke-dasharray",
    ):
        assert needle in page, f"missing client-side piece: {needle}"
    _post_feedback(
        url, {"token": _extract_token(page), "mermaid_source": FLOWCHART, "note": None, "node_annotations": []}
    )
    thread.join(timeout=TEST_TIMEOUT)
    assert holder["value"] == "The user reviewed the diagram source and left it unchanged."


def test_diagram_source_escaping_roundtrips_exactly():
    # The source contains ">" (from "-->"), which must be HTML-escaped to
    # sit safely inside a <textarea>...</textarea> - confirm decoding it
    # recovers exactly the original Mermaid source, not an altered version.
    url, thread, _holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    match = re.search(r'<textarea id="source"[^>]*>(.*?)</textarea>', page, re.DOTALL)
    assert match, "source textarea not found in served page"
    assert html.unescape(match.group(1)) == FLOWCHART
    _post_feedback(url, {"token": _extract_token(page), "mermaid_source": FLOWCHART, "note": None, "node_annotations": []})
    thread.join(timeout=TEST_TIMEOUT)


def test_diagram_review_edited_source_is_returned_verbatim():
    edited = "flowchart TD\n  A[Start] --> C[Middle] --> B[End]"
    url, thread, holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(
        url,
        {
            "token": _extract_token(page),
            "mermaid_source": edited,
            "note": "added the missing middle step",
            "node_annotations": [],
        },
    )
    thread.join(timeout=TEST_TIMEOUT)
    result = holder["value"]
    assert "edited the diagram source" in result
    assert "C[Middle]" in result
    assert "added the missing middle step" in result


def test_diagram_review_node_annotation_is_scoped_and_itemized():
    url, thread, holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(
        url,
        {
            "token": _extract_token(page),
            "mermaid_source": FLOWCHART,  # unedited
            "note": None,
            "node_annotations": [
                {"node_id": "B", "label": "Process", "comment": "should validate input first"},
            ],
        },
    )
    thread.join(timeout=TEST_TIMEOUT)
    result = holder["value"]
    assert "left it unchanged" in result
    assert 'Node "B" ("Process")' in result
    assert "should validate input first" in result
    assert "scoped to that specific node" in result


def test_diagram_review_combines_edit_annotation_and_note():
    edited = "flowchart TD\n  A[Start] --> B[Process] --> D[Validate] --> C[End]"
    url, thread, holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(
        url,
        {
            "token": _extract_token(page),
            "mermaid_source": edited,
            "note": "ship this today",
            "node_annotations": [{"node_id": "D", "label": "Validate", "comment": "needs a timeout guard"}],
        },
    )
    thread.join(timeout=TEST_TIMEOUT)
    result = holder["value"]
    assert "edited the diagram source" in result
    assert "D[Validate]" in result
    assert 'Node "D" ("Validate")' in result
    assert "needs a timeout guard" in result
    assert "Overall note from the user: ship this today" in result


def test_diagram_review_dismiss_without_approving_or_annotating():
    url, thread, holder = _run_and_capture_url(
        open_diagram_review, FLOWCHART, title="d", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(
        url, {"token": _extract_token(page), "mermaid_source": None, "note": None, "node_annotations": []}
    )
    thread.join(timeout=TEST_TIMEOUT)
    assert holder["value"] == "The user closed the review without approving, editing, or annotating the diagram."


def test_diagram_review_times_out_when_nothing_arrives():
    _url, thread, holder = _run_and_capture_url(open_diagram_review, FLOWCHART, title="d", timeout_seconds=1)
    thread.join(timeout=TEST_TIMEOUT)
    assert not thread.is_alive()
    assert "No feedback received within 1s" in holder["value"]


# --- pacing (cooldown + per-process cap) -------------------------------------


def test_pacing_cooldown_delays_the_next_review(monkeypatch):
    # Override the autouse fixture's zeroed cooldown for this one test -
    # this is the test that actually needs a real, measurable gap.
    monkeypatch.setattr(lavish, "REVIEW_COOLDOWN_SECONDS", 0.3)

    url, thread, _holder = _run_and_capture_url(
        open_review, "<html><body>x</body></html>", title="first", timeout_seconds=TEST_TIMEOUT
    )
    page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(url, {"token": _extract_token(page), "feedback": "ok"})
    thread.join(timeout=TEST_TIMEOUT)

    started = time.monotonic()
    url2, thread2, holder2 = _run_and_capture_url(
        open_review, "<html><body>y</body></html>", title="second", timeout_seconds=TEST_TIMEOUT
    )
    elapsed_before_url = time.monotonic() - started
    assert elapsed_before_url >= 0.25, (
        f"second review opened after only {elapsed_before_url:.3f}s - cooldown was not enforced"
    )
    page2 = urllib.request.urlopen(url2, timeout=TEST_TIMEOUT).read().decode()
    _post_feedback(url2, {"token": _extract_token(page2), "feedback": "ok2"})
    thread2.join(timeout=TEST_TIMEOUT)
    assert holder2["value"] == "ok2"


def test_pacing_cap_refuses_after_limit():
    # Cooldown is zeroed by the autouse fixture, so this runs fast even
    # though it opens (MAX + 1) reviews. Uses open_review directly rather
    # than going through the HTTP round trip for the first MAX calls, since
    # what's under test here is the counting, not the server.
    for _ in range(lavish.MAX_REVIEWS_PER_PROCESS):
        url, thread, holder = _run_and_capture_url(
            open_review, "<html><body>x</body></html>", title="t", timeout_seconds=TEST_TIMEOUT
        )
        page = urllib.request.urlopen(url, timeout=TEST_TIMEOUT).read().decode()
        _post_feedback(url, {"token": _extract_token(page), "feedback": "ok"})
        thread.join(timeout=TEST_TIMEOUT)
        assert holder["value"] == "ok"

    # The next one should be refused immediately - no server, no URL ever printed.
    buf_result = open_review("<html><body>x</body></html>", title="one too many", timeout_seconds=TEST_TIMEOUT)
    assert "Not opening another review window" in buf_result
    assert str(lavish.MAX_REVIEWS_PER_PROCESS) in buf_result


# --- dispatch-layer integration: a wrong-type argument from a real tool call ---
# (AI Engineering, ch. 6: "valid tool, invalid parameters" is a named agent
# failure mode - a present key with the wrong type doesn't trip Python's own
# TypeError/KeyError checks in tools.execute(), so it needs its own test
# rather than being assumed covered by those.)


def test_wrong_type_argument_from_a_real_tool_call_fails_gracefully():
    from unittest.mock import MagicMock

    from neuralcode import tools

    fake_call = MagicMock()
    fake_call.function.name = "lavish_diagram"
    # Valid JSON, the right key present, but the wrong type - mermaid_source
    # should be a string. This is the one failure mode that Python's own
    # TypeError (wrong/missing argument) and KeyError (missing key) checks
    # in tools.execute() don't specifically name, since the key is present.
    fake_call.function.arguments = '{"mermaid_source": null, "title": "t"}'

    args, result = tools.execute(fake_call)

    assert args == {"mermaid_source": None, "title": "t"}
    assert isinstance(result, str), "execute() must always return a string the model can read, never raise"
    assert "Error" in result
    assert "lavish_diagram" in result
