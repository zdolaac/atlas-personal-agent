"""Test-session setup.

neuralcode.config reads BASE_URL and API_KEY from the environment at import
time (real credentials, for the actual model calls agent.py makes) - these
tests never call the model, but importing neuralcode.lavish still pulls in
neuralcode.history -> neuralcode.config transitively, so the import fails
before a single test runs unless something is set. setdefault so a real
.env.local or shell environment (someone running these tests on a machine
already configured to actually run the agent) is never overridden.

This has to happen at conftest.py's module level, before pytest imports any
test module, since config.py's os.environ[...] lookups run once at import
time, not per-test.
"""

import os

os.environ.setdefault("BASE_URL", "http://localhost.invalid")
os.environ.setdefault("API_KEY", "test-dummy-key")

import pytest

from neuralcode import lavish


@pytest.fixture(autouse=True)
def _fast_pacing(monkeypatch):
    """Reset lavish's process-scoped review-pacing counters before every
    test, and shrink the cooldown to ~0 so the real 3-second spacing
    doesn't make an 11-test suite take 30+ seconds. The cap
    (MAX_REVIEWS_PER_PROCESS) is left at its real value on purpose -
    test_pacing_cap_refuses_after_limit exercises the real number, not a
    shrunk one, so it's actually testing the shipped behavior.
    """
    lavish._reset_pacing_state_for_tests()
    monkeypatch.setattr(lavish, "REVIEW_COOLDOWN_SECONDS", 0.0)
    yield
    lavish._reset_pacing_state_for_tests()
