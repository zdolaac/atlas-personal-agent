"""A local review loop for HTML artifacts and Mermaid diagrams - Lavish
Editor's core idea, reimplemented in stdlib Python for neural-code.

Two review modes:

- open_review: a general HTML artifact (a plan, table, prototype) with a
  free-text feedback panel injected at the bottom.
- open_diagram_review: a Mermaid diagram, rendered live, with its source
  directly editable next to the render. This is the one that actually
  prevents slop: the user isn't limited to describing what's wrong in
  prose, they fix the diagram itself, see it re-render immediately, and
  what comes back to the agent is the corrected source - not a comment
  the agent has to reinterpret and might reintroduce the same mistake
  trying to apply.

What this is not: real Lavish converts Mermaid into a full Excalidraw
scene - drag nodes, relabel in place, free-draw annotations, then
diffs the edit back into stats (added/removed/moved/relabeled). That is
a bundled visual-canvas library plus real geometry logic, disproportionate
to add here. This gives the same practical guarantee - see the actual
diagram, edit the actual source, get immediate syntax feedback, send back
exactly what should replace it - through Mermaid's own live re-render
instead of a drag-and-drop canvas.

Both modes share one property with the rest of this file: the server
binds to 127.0.0.1 only and is torn down the instant the call returns.
There is no open-ended local web service left running between tool calls.
"""

import json
import secrets
import tempfile
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import history

DEFAULT_TIMEOUT = 900  # 15 minutes - long enough to actually look at something

# Pacing: nothing stops an agent from calling lavish/lavish_diagram
# repeatedly - each call blocks until the user responds, but "blocks" isn't
# the same as "paces itself". An agent that decides to review every trivial
# change opens one interruption after another the instant each is
# dismissed, and a hard-to-please reviewer clicking through fast could
# still get window after window in quick succession. Two independent
# guards, both process-scoped (one neural-code run = one session, matching
# how this CLI is actually used):
#   - a minimum gap enforced between the end of one review and the start
#     of the next, so back-to-back opens can't outrun a human's ability to
#     even notice one before the next appears;
#   - a hard cap on total reviews per process, past which the tool refuses
#     and tells the agent to consolidate instead of silently continuing to
#     interrupt. Both are generous by design - they exist to catch a
#     runaway agent, not to throttle normal use.
REVIEW_COOLDOWN_SECONDS = 3.0
MAX_REVIEWS_PER_PROCESS = 20

_pacing_lock = threading.Lock()
_last_review_end_monotonic: float | None = None
_review_count = 0

# Loaded from a CDN in the reviewer's own browser at review time, not
# fetched by neural-code itself - the same "author-pasted CDN diagram"
# pattern Mermaid and Lavish both rely on. Requires the reviewer's machine
# to have internet access; there is no bundled fallback.
MERMAID_CDN = "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs"

PANEL_TEMPLATE = """
<div id="neuralcode-review-panel" style="
  position: fixed; left: 0; right: 0; bottom: 0; z-index: 2147483647;
  background: #1a1a1a; color: #eee; font: 14px -apple-system, sans-serif;
  padding: 12px 16px; box-shadow: 0 -2px 12px rgba(0,0,0,0.4);
  display: flex; gap: 8px; align-items: flex-end;
">
  <textarea id="neuralcode-review-text" placeholder="Feedback for the agent..."
    style="flex: 1; min-height: 44px; max-height: 160px; resize: vertical;
    background: #2a2a2a; color: #eee; border: 1px solid #444; border-radius: 6px;
    padding: 8px; font: inherit;"></textarea>
  <button id="neuralcode-review-send" style="
    background: #4a9eff; color: #fff; border: none; border-radius: 6px;
    padding: 10px 16px; font: inherit; cursor: pointer;">Send to agent</button>
  <button id="neuralcode-review-dismiss" style="
    background: #333; color: #ccc; border: 1px solid #555; border-radius: 6px;
    padding: 10px 16px; font: inherit; cursor: pointer;">Close, no feedback</button>
  <span id="neuralcode-review-status" style="color: #888; align-self: center;"></span>
</div>
<script>
(function () {
  const TOKEN = %(token)s;
  const status = document.getElementById("neuralcode-review-status");
  const textarea = document.getElementById("neuralcode-review-text");

  function send(feedback) {
    status.textContent = "Sending...";
    fetch("/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: TOKEN, feedback: feedback }),
    })
      .then(() => {
        status.textContent = "Sent - you can close this tab.";
        document.getElementById("neuralcode-review-send").disabled = true;
        document.getElementById("neuralcode-review-dismiss").disabled = true;
      })
      .catch(() => { status.textContent = "Failed to send - is the review still running?"; });
  }

  document.getElementById("neuralcode-review-send").addEventListener("click", () => {
    const value = textarea.value.trim();
    if (value.length === 0) { status.textContent = "Type something first, or use Close."; return; }
    send(value);
  });
  document.getElementById("neuralcode-review-dismiss").addEventListener("click", () => {
    send(null);
  });
})();
</script>
"""

DIAGRAM_PAGE_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>%(title)s</title>
<style>
  body { margin: 0; background: #111; color: #eee; font: 14px -apple-system, sans-serif;
    display: flex; height: 100vh; }
  #source-pane { width: 40%%; display: flex; flex-direction: column; border-right: 1px solid #333; }
  #source-pane h2 { margin: 12px 16px 4px; font-size: 13px; color: #999; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.05em; }
  #source { flex: 1; margin: 0 16px 8px; background: #1a1a1a; color: #eee; border: 1px solid #444;
    border-radius: 6px; padding: 10px; font: 13px ui-monospace, monospace; resize: none; }
  #render-btn { margin: 0 16px 12px; background: #4a9eff; color: #fff; border: none;
    border-radius: 6px; padding: 10px; font: inherit; cursor: pointer; }
  #error-box { margin: 0 16px 12px; padding: 8px 10px; background: #3a1a1a; color: #ff9a9a;
    border-radius: 6px; font: 12px ui-monospace, monospace; white-space: pre-wrap; display: none; }
  #diagram-pane { flex: 1; display: flex; align-items: center; justify-content: center;
    overflow: auto; padding: 24px; box-sizing: border-box; position: relative; }
  #diagram-pane svg { max-width: 100%%; height: auto; }
  #diagram-pane svg .node { cursor: pointer; }
  #diagram-pane svg .node:hover > rect, #diagram-pane svg .node:hover > polygon,
  #diagram-pane svg .node:hover > circle, #diagram-pane svg .node:hover > ellipse {
    stroke: #4a9eff !important; stroke-width: 3px !important; }
  #diagram-pane svg .node[data-neuralcode-annotated="true"] > rect,
  #diagram-pane svg .node[data-neuralcode-annotated="true"] > polygon,
  #diagram-pane svg .node[data-neuralcode-annotated="true"] > circle,
  #diagram-pane svg .node[data-neuralcode-annotated="true"] > ellipse {
    /* Dashed, not just amber - color alone as the only signal is a named
       accessibility antipattern (Read, Communication Patterns, ch. 3):
       distinguishable by more than hue alone for color-vision-deficient
       reviewers, and distinct from the plain hover outline above even in
       a quick glance or a black-and-white screenshot. */
    stroke: #f4c95d !important; stroke-width: 3px !important; stroke-dasharray: 6,3 !important; }
  .neuralcode-node-editor { position: fixed; z-index: 2147483646; background: #222;
    border: 1px solid #f4c95d; border-radius: 6px; padding: 8px; width: 260px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.5); }
  .neuralcode-node-editor textarea { width: 100%%; box-sizing: border-box; min-height: 60px;
    background: #1a1a1a; color: #eee; border: 1px solid #444; border-radius: 4px;
    padding: 6px; font: 13px -apple-system, sans-serif; resize: vertical; }
  .neuralcode-node-editor .row { display: flex; gap: 6px; margin-top: 6px; }
  .neuralcode-node-editor button { flex: 1; border: none; border-radius: 4px; padding: 6px;
    cursor: pointer; font: 12px inherit; }
  .neuralcode-node-editor .save { background: #4a9eff; color: #fff; }
  .neuralcode-node-editor .remove { background: #444; color: #ccc; }
  #annotation-count { margin: 0 16px 8px; font-size: 12px; color: #999; }
</style>
</head>
<body>
  <div id="source-pane">
    <h2>Mermaid source (edit, then Render)</h2>
    <textarea id="source" spellcheck="false">%(source)s</textarea>
    <button id="render-btn">Render</button>
    <div id="error-box"></div>
    <div id="annotation-count">Click any node in the diagram to attach a note to it.</div>
  </div>
  <div id="diagram-pane"><div id="diagram-target">Rendering...</div></div>
  %(panel)s
<script type="module">
  import mermaid from "%(cdn)s";
  mermaid.initialize({ startOnLoad: false, securityLevel: "strict" });

  const sourceBox = document.getElementById("source");
  const target = document.getElementById("diagram-target");
  const errorBox = document.getElementById("error-box");
  const countLabel = document.getElementById("annotation-count");
  let renderCount = 0;

  // node id (Mermaid's own, e.g. "flowchart-A-3") -> { label, comment }
  const nodeAnnotations = new Map();
  let openEditor = null;

  function closeEditor() {
    if (openEditor) { openEditor.remove(); openEditor = null; }
  }

  function nodeLabel(nodeEl) {
    const text = nodeEl.querySelector("text, .nodeLabel");
    return (text ? text.textContent : "").trim().replace(/\\s+/g, " ").slice(0, 120) || "(unlabeled)";
  }

  // Recover the source-level node identifier from Mermaid's generated id
  // ("flowchart-A-3" -> "A") so the agent can match the annotation back to
  // a specific line in the source instead of an opaque generated id alone.
  function sourceNodeId(rawId) {
    const match = /^flowchart-(.+?)-\\d+$/.exec(rawId || "");
    return match ? match[1] : (rawId || "unknown");
  }

  function updateCount() {
    const n = nodeAnnotations.size;
    countLabel.textContent = n === 0
      ? "Click any node in the diagram to attach a note to it."
      : `${n} node${n === 1 ? "" : "s"} annotated - included when you send.`;
  }

  function openNodeEditor(nodeEl, rawId) {
    closeEditor();
    const rect = nodeEl.getBoundingClientRect();
    const key = sourceNodeId(rawId);
    const existing = nodeAnnotations.get(key);

    const box = document.createElement("div");
    box.className = "neuralcode-node-editor";
    box.style.left = Math.min(rect.left, window.innerWidth - 280) + "px";
    box.style.top = Math.min(rect.bottom + 8, window.innerHeight - 140) + "px";
    box.innerHTML =
      '<div style="font-size:12px;color:#f4c95d;margin-bottom:4px;">Node: ' +
      nodeLabel(nodeEl).replace(/</g, "&lt;") + "</div>" +
      '<textarea placeholder="What should change about this node?">' +
      (existing ? existing.comment.replace(/</g, "&lt;") : "") + "</textarea>" +
      '<div class="row"><button class="save">Save</button>' +
      (existing ? '<button class="remove">Remove</button>' : "") + "</div>";
    document.body.appendChild(box);
    openEditor = box;

    box.querySelector(".save").addEventListener("click", () => {
      const comment = box.querySelector("textarea").value.trim();
      if (comment.length === 0) { closeEditor(); return; }
      nodeAnnotations.set(key, { label: nodeLabel(nodeEl), comment });
      nodeEl.setAttribute("data-neuralcode-annotated", "true");
      updateCount();
      closeEditor();
    });
    const removeBtn = box.querySelector(".remove");
    if (removeBtn) {
      removeBtn.addEventListener("click", () => {
        nodeAnnotations.delete(key);
        nodeEl.removeAttribute("data-neuralcode-annotated");
        updateCount();
        closeEditor();
      });
    }
  }

  function attachNodeHandlers() {
    target.querySelectorAll("svg .node").forEach((nodeEl) => {
      nodeEl.addEventListener("click", (event) => {
        event.stopPropagation();
        openNodeEditor(nodeEl, nodeEl.id);
      });
    });
  }

  async function render() {
    const source = sourceBox.value;
    errorBox.style.display = "none";
    try {
      const id = "neuralcode-diagram-" + (renderCount += 1);
      const { svg } = await mermaid.render(id, source);
      target.innerHTML = svg;
      // Re-rendering invalidates old node identities (edits may rename or
      // remove nodes), so annotations tied to the previous render are
      // cleared rather than silently carried over onto the wrong node.
      nodeAnnotations.clear();
      updateCount();
      attachNodeHandlers();
    } catch (error) {
      errorBox.style.display = "block";
      errorBox.textContent = "Invalid Mermaid syntax:\\n" + (error && error.message ? error.message : String(error));
    }
  }

  document.addEventListener("click", closeEditor);
  document.getElementById("render-btn").addEventListener("click", render);
  render();

  // Send/Close on the shared panel must submit the *current* source and the
  // *current* node annotations, not a load-time snapshot.
  window.neuralcodeGetDiagramPayload = () => ({
    mermaid_source: sourceBox.value,
    note: null,
    node_annotations: Array.from(nodeAnnotations.entries()).map(([node_id, v]) => ({
      node_id, label: v.label, comment: v.comment,
    })),
  });
</script>
</body>
</html>
"""

# A second variant of the panel script for diagram review: it sends
# {mermaid_source, note} instead of {feedback}, using the current textarea
# content, not a snapshot from page load.
DIAGRAM_PANEL_SCRIPT = """
<script>
(function () {
  const TOKEN = %(token)s;
  const status = document.getElementById("neuralcode-review-status");
  const noteBox = document.getElementById("neuralcode-review-text");

  function send(dismiss) {
    status.textContent = "Sending...";
    const payload = window.neuralcodeGetDiagramPayload
      ? window.neuralcodeGetDiagramPayload()
      : { mermaid_source: null, note: null };
    if (!dismiss) payload.note = noteBox.value.trim() || null;
    else payload.mermaid_source = null;
    payload.token = TOKEN;
    fetch("/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
      .then(() => {
        status.textContent = "Sent - you can close this tab.";
        document.getElementById("neuralcode-review-send").disabled = true;
        document.getElementById("neuralcode-review-dismiss").disabled = true;
      })
      .catch(() => { status.textContent = "Failed to send - is the review still running?"; });
  }

  document.getElementById("neuralcode-review-send").addEventListener("click", () => send(false));
  document.getElementById("neuralcode-review-dismiss").addEventListener("click", () => send(true));
})();
</script>
"""

DIAGRAM_PANEL_HTML = """
<div id="neuralcode-review-panel" style="
  position: fixed; left: 0; right: 0; bottom: 0; z-index: 2147483647;
  background: #1a1a1a; color: #eee; font: 14px -apple-system, sans-serif;
  padding: 12px 16px; box-shadow: 0 -2px 12px rgba(0,0,0,0.4);
  display: flex; gap: 8px; align-items: flex-end;
">
  <textarea id="neuralcode-review-text" placeholder="Optional note to go with the diagram..."
    style="flex: 1; min-height: 44px; max-height: 120px; resize: vertical;
    background: #2a2a2a; color: #eee; border: 1px solid #444; border-radius: 6px;
    padding: 8px; font: inherit;"></textarea>
  <button id="neuralcode-review-send" style="
    background: #4a9eff; color: #fff; border: none; border-radius: 6px;
    padding: 10px 16px; font: inherit; cursor: pointer;">Send diagram to agent</button>
  <button id="neuralcode-review-dismiss" style="
    background: #333; color: #ccc; border: 1px solid #555; border-radius: 6px;
    padding: 10px 16px; font: inherit; cursor: pointer;">Close, no feedback</button>
  <span id="neuralcode-review-status" style="color: #888; align-self: center;"></span>
</div>
"""


def _inject_panel(html_content: str, token: str) -> str:
    panel = PANEL_TEMPLATE % {"token": json.dumps(token)}
    if "</body>" in html_content:
        return html_content.replace("</body>", panel + "</body>", 1)
    return html_content + panel


def _escape_for_textarea(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _diagram_page(mermaid_source: str, title: str, token: str) -> str:
    panel = DIAGRAM_PANEL_HTML + (DIAGRAM_PANEL_SCRIPT % {"token": json.dumps(token)})
    return DIAGRAM_PAGE_TEMPLATE % {
        "title": title,
        "source": _escape_for_textarea(mermaid_source),
        "panel": panel,
        "cdn": MERMAID_CDN,
    }


def _make_handler(page_bytes: bytes, token: str, result: dict, done: threading.Event):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass  # silence the default request log to stdout

        def do_GET(self):
            if self.path not in ("/", "/index.html"):
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(page_bytes)))
            self.end_headers()
            self.wfile.write(page_bytes)

        def do_POST(self):
            if self.path != "/feedback":
                self.send_response(404)
                self.end_headers()
                return
            length = int(self.headers.get("Content-Length", 0))
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                self.send_response(400)
                self.end_headers()
                return
            if payload.get("token") != token:
                self.send_response(403)
                self.end_headers()
                return
            result["payload"] = payload
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok": true}')
            done.set()

    return Handler


def _run_server(page_bytes: bytes, token: str, title: str, timeout_seconds: int):
    """Shared plumbing: serve one page, wait for one POST /feedback, tear down.

    Returns the posted JSON payload dict, or None on timeout.
    """
    result: dict = {}
    done = threading.Event()
    handler = _make_handler(page_bytes, token, result, done)

    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/"

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    print(f'Review "{title}" open at {url} (waiting up to {timeout_seconds}s)')
    if not webbrowser.open(url):
        print("Could not auto-open a browser - open the URL above manually.")

    try:
        arrived = done.wait(timeout=timeout_seconds)
    finally:
        server.shutdown()
        server.server_close()

    return result.get("payload") if arrived else None


def _enforce_pacing() -> str | None:
    """Call before opening a new review. Returns a message the caller
    should return immediately, without opening anything, if the process
    has hit the review cap. Otherwise blocks out any remaining cooldown
    and returns None.

    The count-and-cap check happens under the lock (so two near-simultaneous
    calls can't both slip past the cap); the cooldown sleep happens after
    releasing it, so one waiting caller doesn't hold up another's count
    check.
    """
    global _last_review_end_monotonic, _review_count

    with _pacing_lock:
        _review_count += 1
        count = _review_count
        last_end = _last_review_end_monotonic

    if count > MAX_REVIEWS_PER_PROCESS:
        return (
            f"Not opening another review window - this process has already opened "
            f"{MAX_REVIEWS_PER_PROCESS} of them. That many separate interruptions is "
            "worse for the user than fewer, larger ones: consolidate whatever is left "
            "into a single review instead of requesting more."
        )

    if last_end is not None:
        remaining = REVIEW_COOLDOWN_SECONDS - (time.monotonic() - last_end)
        if remaining > 0:
            time.sleep(remaining)

    return None


def _mark_review_ended() -> None:
    global _last_review_end_monotonic
    with _pacing_lock:
        _last_review_end_monotonic = time.monotonic()


def _reset_pacing_state_for_tests() -> None:
    """Test-only. Not part of the public API - production code has no
    legitimate reason to reset these counters mid-process."""
    global _last_review_end_monotonic, _review_count
    with _pacing_lock:
        _last_review_end_monotonic = None
        _review_count = 0


def open_review(html_content: str, title: str = "Review", timeout_seconds: int = DEFAULT_TIMEOUT) -> str:
    """Open an HTML artifact for review and block for free-text feedback."""
    pacing_message = _enforce_pacing()
    if pacing_message is not None:
        return pacing_message

    token = secrets.token_urlsafe(16)
    page_bytes = _inject_panel(html_content, token).encode("utf-8")

    try:
        payload = _run_server(page_bytes, token, title, timeout_seconds)
    finally:
        _mark_review_ended()

    if payload is None:
        return history.cap(f"No feedback received within {timeout_seconds}s; the review page was closed.")

    feedback = payload.get("feedback")
    if feedback is None:
        return "The user closed the review without leaving feedback."
    return history.cap(str(feedback))


def open_diagram_review(
    mermaid_source: str, title: str = "Diagram", timeout_seconds: int = DEFAULT_TIMEOUT
) -> str:
    """Open a Mermaid diagram for review; the user can edit the source
    directly, click individual nodes to attach notes to them, and see it
    re-render live before sending it back.

    Returns a string that plainly separates three kinds of signal: whether
    the diagram was approved unchanged, whether the source was edited
    (with the corrected source included verbatim), and any per-node notes
    the user attached by clicking specific nodes - each tied to the exact
    node it's about, not folded into one paragraph of prose the agent has
    to disentangle.
    """
    pacing_message = _enforce_pacing()
    if pacing_message is not None:
        return pacing_message

    token = secrets.token_urlsafe(16)
    page_bytes = _diagram_page(mermaid_source, title, token).encode("utf-8")

    try:
        payload = _run_server(page_bytes, token, title, timeout_seconds)
    finally:
        _mark_review_ended()

    if payload is None:
        return history.cap(f"No feedback received within {timeout_seconds}s; the review page was closed.")

    edited_source = payload.get("mermaid_source")
    note = payload.get("note")
    node_annotations = payload.get("node_annotations") or []

    if edited_source is None and not node_annotations:
        return "The user closed the review without approving, editing, or annotating the diagram."

    parts = []

    if edited_source is not None:
        original_normalized = mermaid_source.strip()
        edited_normalized = str(edited_source).strip()
        if edited_normalized == original_normalized:
            parts.append("The user reviewed the diagram source and left it unchanged.")
        else:
            parts.append(
                "The user edited the diagram source before approving it. Use this corrected "
                "Mermaid source in place of what you had, rather than reconstructing it from "
                f"a description:\n\n```mermaid\n{edited_normalized}\n```"
            )

    if node_annotations:
        lines = ["The user clicked specific nodes and attached notes to them:"]
        for entry in node_annotations:
            if not isinstance(entry, dict):
                continue
            node_id = str(entry.get("node_id", "?"))
            label = str(entry.get("label", "")).strip()
            comment = str(entry.get("comment", "")).strip()
            if not comment:
                continue
            label_part = f' ("{label}")' if label else ""
            lines.append(f'- Node "{node_id}"{label_part}: {comment}')
        if len(lines) > 1:
            parts.append(
                "\n".join(lines)
                + "\n\nTreat each line as a change scoped to that specific node - "
                "don't apply a general rewrite where a targeted edit was asked for."
            )

    if note:
        parts.append(f"Overall note from the user: {note}")

    return history.cap("\n\n".join(parts))


def write_temp_html(html_content: str, filename: str = "review.html") -> Path:
    """Optional helper: park a copy on disk, e.g. for share_file-style tools."""
    directory = Path(tempfile.mkdtemp(prefix="neuralcode-review-"))
    path = directory / filename
    path.write_text(html_content, encoding="utf-8")
    return path
