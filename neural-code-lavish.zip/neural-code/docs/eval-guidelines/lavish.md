# Evaluation guideline: `neuralcode/lavish.py`

This exists separately from `tests/test_lavish.py` on purpose. A guideline
written *after* the tests just restates what the tests already check; the
point of writing it down is that it can be read - and disagreed with -
without reading test code, and that the next change to this file gets
checked against it rather than against whatever the last diff happened to
assert. AI Engineering (Huyen, ch. 4) calls this out as its own step,
separate from picking a method: define what "correct" means before you
measure it.

Each criterion below names the test(s) that currently prove it, so a gap is
visible: a criterion with no test is unverified, not just unwritten.

## `open_review` (free-text HTML artifact review)

1. **The served page contains the original content plus the feedback
   panel** - the artifact isn't replaced or wrapped away.
   → `test_open_review_serves_injected_panel`
2. **A request without the correct per-review token is rejected (403)**,
   and rejection doesn't tear down the server - a stray or forged request
   must not be able to end someone else's review.
   → `test_open_review_rejects_wrong_token`
3. **Explicit dismissal ("Close, no feedback") is distinguishable from
   silence** - the agent must be able to tell "the user looked and had
   nothing to add" apart from "the user never saw this."
   → `test_open_review_dismiss_without_feedback`
4. **A review that gets no response within its timeout says so plainly**,
   naming the actual timeout used, not a generic failure.
   → `test_open_review_times_out_when_nothing_arrives`

## `open_diagram_review` (Mermaid source + per-node review)

5. **Whatever the user typed into the source box survives round-trip
   exactly** - HTML-escaping for safe embedding must not silently alter
   the Mermaid source a re-render or a submission depends on.
   → `test_diagram_source_escaping_roundtrips_exactly`
6. **An unedited, unannotated, approved diagram is reported as unchanged**
   - the agent must not be told something changed when nothing did.
   → `test_diagram_page_has_click_to_annotate_machinery`
7. **An edited diagram's corrected source comes back verbatim**, not
   summarized or re-described - the whole point of this tool over a
   free-text comment is that the agent never has to reconstruct the fix.
   → `test_diagram_review_edited_source_is_returned_verbatim`
8. **A per-node annotation names the node, its own label, and the
   comment - never folded into one undifferentiated paragraph** - and is
   explicitly framed to the agent as a change scoped to that node, not
   license for a general rewrite.
   → `test_diagram_review_node_annotation_is_scoped_and_itemized`
9. **Source edits, per-node notes, and an overall note can all be present
   in one submission and must all survive separately** - none silently
   drops another when combined.
   → `test_diagram_review_combines_edit_annotation_and_note`
10. **Dismissal without any signal (no edit, no annotation) is reported
    as exactly that** - not conflated with either approval or a timeout.
    → `test_diagram_review_dismiss_without_approving_or_annotating`

## Pacing (both tools)

The two thresholds below (`REVIEW_COOLDOWN_SECONDS = 3.0`,
`MAX_REVIEWS_PER_PROCESS = 20`) are unvalidated defaults, not measured
values - picked because they were easy to reason about and easy to test,
not because any real usage data says 3 seconds or 20 reviews is where
annoyance actually starts. This is worth stating plainly rather than
letting a passing test suite imply otherwise: the tests below prove the
*mechanism* enforces whatever threshold is configured, not that the
configured numbers are the right ones. If this tool sees real use, the
numbers - not the mechanism - are what should get revisited first, ideally
against actual sessions where a reviewer got annoyed, not against a guess.

11. **Two reviews opened back to back are still separated by the
    configured cooldown** - "the call blocks until the user responds"
    is not the same guarantee as "the user has time to notice a new
    window before it appears."
    → `test_pacing_cooldown_delays_the_next_review`
12. **A process that opens more than `MAX_REVIEWS_PER_PROCESS` reviews is
    refused, with a message that tells the agent to consolidate** - not
    silently rate-limited, and not silently allowed to continue.
    → `test_pacing_cap_refuses_after_limit`
13. **The cap and cooldown are process-global, not per-call** - a
    subagent invoked via `task` and the main agent share the same
    counters. (Currently *implied* by the implementation - both read the
    same module-level state - but not independently asserted by a test
    that actually calls through `task`. This is the one gap in this
    document: a real criterion with no direct test.)
14. **A tool call that reaches this file with a present-but-wrong-typed
    argument (valid JSON, right key, wrong type - e.g.
    `mermaid_source: null`) fails with a clear, model-readable error
    through the dispatch layer's generic exception handler, and never
    crashes the session.** This is distinct from a missing argument or a
    wrong argument name (Python's own `TypeError`/`KeyError` catch those);
    a present wrong-typed value slips past both and needs its own check.
    Named directly by *AI Engineering* ch. 6's agent-failure taxonomy
    ("valid tool, invalid parameters") - verified here, not assumed, since
    reasoning through the code by eye said this would work before the test
    confirmed it did.
    → `test_wrong_type_argument_from_a_real_tool_call_fails_gracefully`
15. **The "annotated" node state is visually distinguishable by more than
    color alone** (dashed outline, not just amber) - named directly by
    Read's *Communication Patterns* ch. 3, "relying on color to
    communicate" antipattern: a state shown only via hue is invisible or
    ambiguous to color-vision-deficient reviewers and indistinguishable
    from the hover state at a glance or in a grayscale screenshot.
    → `test_diagram_page_has_click_to_annotate_machinery` (checks
    `stroke-dasharray` is present; cannot verify actual visual
    distinguishability without a real browser and a real reviewer's eyes -
    named as a limit, not silently assumed covered)

## Explicitly out of scope for this file

- Whether the click-to-annotate UI *feels* good, whether the floating
  editor's position is ever visually awkward, whether the highlight
  colors are legible on every color scheme - none of this is testable
  without a real browser, and this suite doesn't pretend otherwise. See
  the caveat at the top of `tests/test_lavish.py`.
- Whether Mermaid itself renders a given diagram correctly - that's
  Mermaid's contract with its own users, not something this tool adds a
  guarantee about.
